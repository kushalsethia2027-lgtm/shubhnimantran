import { chromium } from '@playwright/test';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const decks=[
{slug:'01-outstation-guests',title:'The outstation guest checklist',caption:'The wedding welcome starts before the venue. When relatives arrive on different trains and flights, each travel group needs its own arrival details and a clear pickup plan. Save this checklist for your next family planning call. Nimantran brings guest records, travel groups and shared logistics into one private wedding workspace. Explore the planner through ni-man-tran.app. #WeddingPlanning #IndianWedding #WeddingGuests #Nimantran',slides:[
['GUEST & TRAVEL PLANNER','5 details to collect before your guests arrive.','A practical checklist for the family organising an outstation wedding.','SAVE FOR YOUR PLANNING CALL'],
['01 / WHO IS COMING','Count people, not just families.','List each adult and child. Track their RSVP individually so your confirmed count stays clear.','FAMILY → MEMBERS → RSVP'],
['02 / WHO TRAVELS TOGETHER','One family can have two arrival times.','Create a separate travel group when relatives take different flights or trains.','TRAVEL GROUP A  /  TRAVEL GROUP B'],
['03 / THE ARRIVAL DETAILS','Get the station as well as the time.','Collect the arrival date, time, terminal or station, and flight or train number.','ASK FOR THE EXACT ARRIVAL POINT'],
['04 / THE PICKUP PLAN','Give each pickup an owner.','Record the vehicle, driver contact and pickup time. Confirm the details with the people involved.','NEEDED → ASSIGNED → COMPLETED'],
['05 / THE STAY','Put the room plan in writing.','Record the hotel, check-in and check-out dates, and room count. Confirm the booking separately.','A PLANNER ENTRY IS NOT A HOTEL BOOKING'],
['TWO FAMILIES. ONE WEDDING PLAN.','Give every arrival a clearer plan.','Explore Nimantran’s Guest & Travel Planner.','VISIT NI-MAN-TRAN.APP']
]},
{slug:'02-family-organisers',title:'A plan for the family organiser',caption:'The cousin coordinating arrivals deserves a clear plan too. Split responsibility by family, keep individual RSVPs current and review shared pickups together. Nimantran gives bride-side and groom-side planners a common logistics view while each manages their own family records. Send this to the person coordinating your wedding guests. #WeddingOrganisation #BrideAndGroom #WeddingPlanning #Nimantran',slides:[
['FOR THE FAMILY ORGANISER','4 habits for a clearer wedding guest plan.','For the sibling, cousin or couple keeping everyone’s arrival details together.','A GUIDE FOR BOTH FAMILIES'],
['01 / DIVIDE THE WORK','Choose one planner on each side.','Agree who keeps bride-side records current and who handles groom-side records.','TWO RESPONSIBILITIES. ONE SHARED PLAN.'],
['02 / KEEP THE COUNT CLEAR','Update each person’s RSVP.','A family reply can hide a different answer for one member. Keep individual confirmations visible.','CONFIRMED / PENDING / DECLINED'],
['03 / SHARE THE JOURNEY','Review arrivals together.','Keep separately travelling relatives in separate travel groups. Check what is still missing before arranging pickups.','ONE FAMILY CAN HAVE SEVERAL JOURNEYS'],
['04 / CLOSE THE LOOP','Confirm the handoff.','Before marking a pickup assigned, check the driver contact, vehicle and time. Update the status when the pickup is complete.','MAKE THE NEXT ACTION CLEAR'],
['INSIDE NIMANTRAN','Your side’s records. A shared logistics view.','Bride-side and groom-side planners manage their families. Both can coordinate pickups and accommodation.','PRIVATE PLANNING REQUIRES SIGN-IN'],
['SHARE THE RESPONSIBILITY','Send this to your family organiser.','Give the person coordinating guests a useful starting point.','SHARE THIS CHECKLIST']
]},
{slug:'03-personal-invitations',title:'A personal invitation in your voice',caption:'A familiar voice makes an invitation feel personal. In Nimantran’s browser studio, review the words, record an individual voice or camera message, then generate and download the invitation. Record each guest’s personalised wording yourself; the app uses your recording unchanged. Keep the tab open until your file is downloaded, and play it before sharing. Try the studio at ni-man-tran.app/demo/. #WeddingInvitation #VideoInvitation #IndianWedding #Nimantran',slides:[
['THE PERSONAL INVITATION GUIDE','4 steps to an invitation in your own voice.','A real recorded message, with wedding details and a downloadable video.','FROM YOUR FAMILY TO THEIRS'],
['01 / SET THE DETAILS','Start with the essentials.','Check the couple’s names, wedding date and venue before creating your invitation.','GET THE DETAILS RIGHT FIRST'],
['02 / REVIEW THE WORDS','Make the message sound like you.','Review the guest’s script before approving it. Say their name the way your family would.','PERSONAL WORDS. A FAMILIAR VOICE.'],
['03 / RECORD YOUR MESSAGE','Choose voice or camera.','Record that guest’s personalised message. Nimantran uses the take as recorded, including the names you say.','RECORD EACH PERSONALISED MESSAGE'],
['04 / GENERATE & CHECK','Download it. Then press play.','Generate the invitation and download the file. Check the sound and picture before you share it yourself.','KEEP THE TAB OPEN UNTIL DOWNLOADED'],
['MAKE IT FEEL PERSONAL','Speak to the person you’re inviting.','“Rajesh uncle, we would love to have you with us.” A specific greeting is a thoughtful place to start.','EXAMPLE WORDING'],
['YOUR VOICE. YOUR INVITATION.','Try a personal recording.','Open the invitation studio and create your own message.','VISIT NI-MAN-TRAN.APP/DEMO/']
]}
];
const esc=s=>s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
const css=`*{box-sizing:border-box}body{margin:0;background:#e8dfd3;color:#47202a;font-family:Arial,sans-serif}.slide{position:relative;width:1080px;height:1350px;padding:80px 84px;overflow:hidden;background:#fbf5e9;break-after:page}.slide:before{content:'';position:absolute;width:650px;height:650px;right:-390px;top:-300px;border:1px solid #bda26b;border-radius:50%;box-shadow:0 0 0 32px #fbf5e9,0 0 0 33px #d6c5a0,0 0 0 65px #fbf5e9,0 0 0 66px #e4d8bd}.brand{font-family:Georgia,serif;font-size:40px;letter-spacing:3px}.rule{height:1px;background:#cdb98b;margin:32px 0 65px}.eyebrow{font-size:23px;letter-spacing:3px;line-height:1.5;color:#846831;font-weight:bold;max-width:850px}h1{font:normal 90px/1.06 Georgia,serif;letter-spacing:-3px;margin:32px 0;max-width:900px}.body{font-size:36px;line-height:1.48;max-width:850px;color:#684c50;margin:0}.note{position:absolute;left:84px;right:84px;bottom:170px;min-height:110px;display:flex;align-items:center;border-top:1px solid #cdb98b;border-bottom:1px solid #cdb98b;font-size:23px;line-height:1.5;letter-spacing:1.8px;color:#785e2e;font-weight:bold}.footer{position:absolute;bottom:74px;left:84px;right:84px;display:flex;justify-content:space-between;font-size:22px;letter-spacing:1px}.cover{background:#542333;color:#fff7e8}.cover:before{opacity:.22}.cover .rule{background:#9d7b60}.cover h1{font-size:102px}.cover .body{color:#ead9cd}.cover .eyebrow,.cover .note{color:#e1c894}.cover .note{border-color:#987357}.end h1{font-size:98px}@page{size:1080px 1350px;margin:0}@media print{body{background:none}.slide:last-child{break-after:auto}}`;
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox'],headless:true});
try{
const page=await browser.newPage({viewport:{width:1080,height:1350},deviceScaleFactor:1});
for(const d of decks){
const dir=path.join(root,d.slug);await fs.mkdir(dir,{recursive:true});
const html=`<!doctype html><html lang="en"><meta charset="utf-8"><title>${esc(d.title)}</title><style>${css}</style><body>${d.slides.map((s,i)=>`<section class="slide ${i===0?'cover':''} ${i===6?'end':''}"><div class="brand">nimantran<span style="color:#b89656"> ✦</span></div><div class="rule"></div><div class="eyebrow">${esc(s[0])}</div><h1>${esc(s[1])}</h1><p class="body">${esc(s[2])}</p><div class="note">${esc(s[3])}</div><div class="footer"><span>ni-man-tran.app</span><span>${String(i+1).padStart(2,'0')} / 07 ${i<6?'→':''}</span></div></section>`).join('')}</body></html>`;
await fs.writeFile(path.join(dir,'editable.html'),html);
await page.setContent(html);await page.evaluate(()=>document.fonts.ready);
for(let i=0;i<7;i++){
const slide=page.locator('.slide').nth(i);
const fits=await slide.evaluate(el=>{const p=el.querySelector('.body').getBoundingClientRect(),n=el.querySelector('.note').getBoundingClientRect();return p.bottom+30<n.top});
if(!fits)throw Error(`${d.slug} slide ${i+1} overflow`);
await slide.screenshot({path:path.join(dir,`slide-${String(i+1).padStart(2,'0')}.png`)});
}
await page.pdf({path:path.join(dir,'carousel.pdf'),printBackground:true,preferCSSPageSize:true});
await fs.writeFile(path.join(dir,'caption.txt'),d.caption+'\n');
}
await fs.writeFile(path.join(root,'content.json'),JSON.stringify(decks,null,2));
console.log('Created 21 PNG slides, 3 PDFs, captions and editable HTML. All text clearance checks passed.');
}finally{await browser.close()}
