# Nimantran carousel pack

Created 27 October 2026 using the installed marketingskills `social` skill and its carousel-frameworks reference, plus `.agents/product-marketing.md`.

Three Instagram-first carousels, seven slides each, 1080 × 1350 PNG. Each uses the Value-Stack framework: a specific promise, useful individual steps, and one final action. The second and third add a clearly separate product/context slide after delivering the promised four steps. No invented customer results, statistics, screenshots or testimonials.

## Use

1. Choose a numbered folder and upload `slide-01.png` through `slide-07.png` in order as one Instagram carousel.
2. Copy that folder's `caption.txt`. “Visit” calls to action use the visible domain; Instagram captions do not provide clickable links. Put the destination in your profile link if you want a clickable route.
3. For a LinkedIn document post, upload the corresponding `carousel.pdf` and adapt the caption to your own voice.
4. `editable.html` is the editable layout; `content.json` holds copy. Update `render.mjs` and run `node docs/marketing/nimantran/carousels/render.mjs` from the project root to regenerate. Requires installed @playwright/test and Chromium at /usr/bin/chromium.

Slide text in `content.json` provides the basis for accessible alt text. Describe the slide heading and its supporting instruction, rather than repeating decorative shapes. All slides use cream/maroon typography, with no private guest data or customer photos.

## Suggested organic sequence

Publish the outstation checklist first, family organiser guide next, and invitation guide last, spaced across a week. Adjust timing to your audience; no optimal posting time is known. Compare saves, shares, profile visits and attributable planner/studio visits. No posts have been published or scheduled.

## Verification

Rendered 21 PNGs and three seven-page PDFs. Automated text-clearance checks passed for all slides; contact sheet visually reviewed. PDF print sizes match the 4:5 layout. No app source or deployment configuration changed.
